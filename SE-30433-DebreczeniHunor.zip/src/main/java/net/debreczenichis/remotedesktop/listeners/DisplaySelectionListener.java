package net.debreczenichis.remotedesktop.listeners;

public interface DisplaySelectionListener {
    void selected(int selectionNr, int width, int height);
}
