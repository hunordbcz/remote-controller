package net.debreczenichis.remotedesktop.controller;

import io.rsocket.metadata.WellKnownMimeType;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import net.debreczenichis.remotedesktop.listeners.ScreenShareEventListener;
import net.debreczenichis.remotedesktop.model.User;
import net.debreczenichis.remotedesktop.model.socket.RemoteImage;
import net.debreczenichis.remotedesktop.model.socket.events.RemoteEvent;
import net.debreczenichis.remotedesktop.ui.ScreenShare;
import net.debreczenichis.remotedesktop.util.SerializerUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.messaging.rsocket.RSocketRequester;
import org.springframework.messaging.rsocket.RSocketStrategies;
import org.springframework.security.rsocket.metadata.SimpleAuthenticationEncoder;
import org.springframework.security.rsocket.metadata.UsernamePasswordMetadata;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.util.MimeType;
import org.springframework.util.MimeTypeUtils;
import reactor.core.Disposable;

import javax.annotation.PreDestroy;
import javax.swing.*;
import java.awt.*;
import java.util.Objects;

@Controller
@Slf4j
@Component
public class RClientController {

    private static final MimeType SIMPLE_AUTH = MimeTypeUtils.parseMimeType(WellKnownMimeType.MESSAGE_RSOCKET_AUTHENTICATION.getString());
    private static volatile Disposable screenShareDisposable;
    @Value("${spring.rsocket.server.port}")
    private int serverPort;
    private RSocketRequester rsocketRequester;
    private RSocketRequester.Builder rsocketRequesterBuilder;
    private RSocketStrategies rsocketStrategies;
    private String host;

    @Autowired
    public RClientController(RSocketRequester.Builder builder,
                             @Qualifier("rSocketStrategies") RSocketStrategies strategies) {
        this.rsocketRequesterBuilder = builder;
        this.rsocketStrategies = strategies;
    }

    private boolean userCheck() {
        return null != this.rsocketRequester && !this.rsocketRequester.rsocket().isDisposed();
    }

    @SneakyThrows
    public void login(String host, String username, String password) {
        this.host = host;
        log.info("Connecting with {}", username);
        UsernamePasswordMetadata user = new UsernamePasswordMetadata(username, password);
        this.rsocketRequester = rsocketRequesterBuilder
                .setupRoute("login-server")
                .setupData(Objects.requireNonNull(SerializerUtil.toString(User.getInstance())))
                .setupMetadata(user, SIMPLE_AUTH)
                .rsocketStrategies(builder ->
                        builder.encoder(new SimpleAuthenticationEncoder())
                )
                .connectTcp(host, serverPort)
                .doOnError(error ->
                        SwingUtilities.invokeLater(() -> JOptionPane.showMessageDialog(null, error.getMessage(), "Error on connection", JOptionPane.ERROR_MESSAGE))
                )
                .onErrorStop()
                .block();

        this.rsocketRequester.rsocket()
                .onClose()
                .doOnError(error -> log.warn("Connection CLOSED"))
                .doFinally(consumer -> log.info("Disconnected from server"))
                .subscribe();
    }

    @PreDestroy
    public void preDestroy() {
        if (!userCheck()) {
            return;
        }
        screenShareDisposable.dispose();
        this.logout();
    }

    public void logout() {
        if (userCheck()) {
            this.rsocketRequester.rsocket().dispose();
            this.host = "UNKWN";
            log.info("Logged out.");
        } else {
            log.warn("Please log in to the server first");
        }
    }


    public void quitScreenShare(boolean allowControl) {
        if (userCheck() && screenShareDisposable != null) {
            screenShareDisposable.dispose();
            displays(allowControl);
        } else {
            log.warn("Please log in to the server first");
        }
    }

    public void displays(boolean allowControl) {
    }

    public void screenShare(final int screenNr, int width, int height, boolean allowControl) {
        if (!userCheck()) {
            return;
        }

        final ScreenShare screenShare = new ScreenShare(host + (allowControl ? " - CONTROL" : " - VIEW"), screenNr, new Dimension(width, height), allowControl);
        screenShare.addEventListener(new ScreenShareEventListener() {
            @Override
            public void newRemoteEvent(RemoteEvent event) {
                sendRemoteEvent(event);
            }

            @Override
            public void quitButtonPressed() {
                quitScreenShare(allowControl);
            }
        });

        screenShareDisposable = rsocketRequester
                .route("image-stream")
                .data(screenNr)
                .retrieveFlux(RemoteImage.class)
                .subscribe(screenShare::updateImage);
    }

    public void sendRemoteEvent(RemoteEvent remoteEvent) {
        if (!userCheck() || screenShareDisposable.isDisposed()) {
            return;
        }

        log.info("Sending {}", remoteEvent);
        rsocketRequester
                .route("remote-event")
                .data(Objects.requireNonNull(SerializerUtil.toString(remoteEvent)))
                .send()
                .block();
    }
}