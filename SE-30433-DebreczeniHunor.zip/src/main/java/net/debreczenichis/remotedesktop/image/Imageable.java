package net.debreczenichis.remotedesktop.image;

import java.awt.image.BufferedImage;

interface Imageable {
    BufferedImage takeScreenshot();
}
